#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "graph.h"

void menu (BITMAP* ecran, BITMAP* Menu,BITMAP* Jouer, BITMAP* Commandes, BITMAP* Quitter, int v, Graph a);

void menubis (BITMAP* ecran, BITMAP* Menubis, BITMAP *Menubis1, BITMAP *Menubis2, BITMAP *Menubis3,BITMAP* Retour, BITMAP* Menu,BITMAP* Jouer, BITMAP* Commandes, BITMAP* Quitter, Graph a);

#endif // MENU_H_INCLUDED
