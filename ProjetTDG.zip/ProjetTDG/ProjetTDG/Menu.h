#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED



void menu (BITMAP* ecran, BITMAP* Menu,BITMAP* Jouer, BITMAP* Commandes, BITMAP* Quitter, int v);

void menubis (BITMAP* ecran, BITMAP* Menubis, BITMAP *Menubis1, BITMAP *Menubis2, BITMAP *Menubis3,BITMAP* Retour, BITMAP* Menu,BITMAP* Jouer, BITMAP* Commandes, BITMAP* Quitter);

#endif // MENU_H_INCLUDED
